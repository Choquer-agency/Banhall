"use client";
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// fixture:pdf-fixture
var pdf_fixture_exports = {};
__export(pdf_fixture_exports, {
  GlobalWorkerOptions: () => GlobalWorkerOptions,
  getDocument: () => getDocument
});
var GlobalWorkerOptions, getDocument;
var init_pdf_fixture = __esm({
  "fixture:pdf-fixture"() {
    GlobalWorkerOptions = {};
    getDocument = (...args) => globalThis.pdfProbe.getDocument(...args);
  }
});

// shared/documentStatus.ts
var SUPPORTED_EXTENSIONS = [
  "txt",
  "md",
  "markdown",
  "pdf",
  "docx",
  "msg",
  "eml",
  "mbox",
  "xlsx",
  "xls",
  "csv",
  "png",
  "jpg",
  "jpeg",
  "webp",
  "gif"
];
var IMAGE_EXTENSIONS = ["png", "jpg", "jpeg", "webp", "gif"];
var SUPPORTED_ACCEPT = ".txt,.md,.markdown,.pdf,.docx,.msg,.eml,.mbox,.xlsx,.xls,.csv,.png,.jpg,.jpeg,.webp,.gif";
var SUPPORTED_LABEL = "PDF, Word (.docx), Excel (.xlsx/.xls/.csv), email (.eml/.msg/.mbox), images (.png/.jpg/.webp/.gif), .txt, .md";
function getFileExtension(name) {
  const m = name.toLowerCase().match(/\.([a-z0-9]+)$/);
  return m ? m[1] : "";
}
function isSupportedFile(name) {
  return SUPPORTED_EXTENSIONS.includes(
    getFileExtension(name)
  );
}
function isImageFile(name) {
  return IMAGE_EXTENSIONS.includes(getFileExtension(name));
}
var CAP_TRUNCATION_MARKER = "\n\n[Document truncated \u2014 text exceeded the size limit]";
function pdfPageStopMarker(page) {
  return `
[Stopped reading at page ${page} \u2014 document too large or slow to parse (likely drawings/scans with little extractable text)]`;
}
function mboxOverflowMarker(remaining) {
  return `

[${remaining} more message(s) in this mailbox were not included]`;
}
var PROCESSING_STATUSES = [
  "ready",
  "ready_truncated",
  "reference_only",
  "could_not_read",
  "skipped_unsupported"
];
var RECEIPT_STATUSES = [
  ...PROCESSING_STATUSES,
  "upload_failed"
];
function normalizeExtractedText(text) {
  return text.replace(/\r\n?/g, "\n").replace(/\u00A0/g, " ").replace(/[ \t]+$/gm, "").replace(/\n{3,}/g, "\n\n").trim();
}

// src/lib/parseDocument.ts
var MAX_CONTENT_CHARS = 4e5;
var PDF_PARSE_TIMEOUT_MS = 6e4;
var ParseTimeout = class extends Error {
  constructor() {
    super("parse timeout");
  }
};
function withDeadline(promise, deadline) {
  const ms = deadline - Date.now();
  if (ms <= 0) {
    void promise.catch(() => {
    });
    return Promise.reject(new ParseTimeout());
  }
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new ParseTimeout()), ms);
    })
  ]).finally(() => clearTimeout(timer));
}
function capContent(content) {
  const normalized = normalizeExtractedText(content);
  if (normalized.length <= MAX_CONTENT_CHARS) return normalized;
  return normalized.slice(0, MAX_CONTENT_CHARS) + CAP_TRUNCATION_MARKER;
}
function fmtPerson(name, email) {
  const n = (name ?? "").trim();
  const e = (email ?? "").trim();
  if (n && e && e.toLowerCase() !== n.toLowerCase()) return `${n} <${e}>`;
  return n || e;
}
function emailToText(e) {
  const header = [];
  if (e.subject) header.push(`Subject: ${e.subject}`);
  if (e.from) header.push(`From: ${e.from}`);
  if (e.to) header.push(`To: ${e.to}`);
  if (e.date) header.push(`Date: ${e.date}`);
  const body = (e.body ?? "").replace(/\r\n/g, "\n").trim();
  return [header.join("\n"), body].filter(Boolean).join("\n\n").trim();
}
function htmlToText(html) {
  return html.replace(/<(script|style)[\s\S]*?<\/\1>/gi, "").replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|li|h[1-6]|tr)>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"').replace(/&#39;/gi, "'").replace(/\n{3,}/g, "\n\n").trim();
}
async function emlToText(raw) {
  const { default: PostalMime } = await import("postal-mime");
  const email = await PostalMime.parse(raw);
  const to = (email.to ?? []).map((r) => fmtPerson(r.name, r.address)).filter(Boolean).join(", ");
  const body = email.text && email.text.trim() ? email.text : email.html ? htmlToText(email.html) : "";
  return emailToText({
    subject: email.subject,
    from: fmtPerson(email.from?.name, email.from?.address),
    to,
    date: email.date ? new Date(email.date).toLocaleString() : void 0,
    body
  });
}
async function parseFileToText(file) {
  const name = file.name;
  const lower = name.toLowerCase();
  if (lower.endsWith(".txt")) {
    return { fileName: name, fileType: "txt", content: capContent(await file.text()) };
  }
  if (lower.endsWith(".md") || lower.endsWith(".markdown")) {
    return { fileName: name, fileType: "md", content: capContent(await file.text()) };
  }
  if (lower.endsWith(".docx")) {
    const mammoth = await import("mammoth");
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return { fileName: name, fileType: "docx", content: capContent(result.value.trim()) };
  }
  if (lower.endsWith(".pdf")) {
    const pdfjs = await Promise.resolve().then(() => (init_pdf_fixture(), pdf_fixture_exports));
    pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
    const arrayBuffer = await file.arrayBuffer();
    const deadline = Date.now() + PDF_PARSE_TIMEOUT_MS;
    const loadingTask = pdfjs.getDocument({
      data: arrayBuffer,
      useSystemFonts: true
    });
    let text = "";
    let truncatedAtPage = 0;
    try {
      const pdf = await withDeadline(loadingTask.promise, deadline);
      for (let i = 1; i <= pdf.numPages; i++) {
        try {
          const page = await withDeadline(pdf.getPage(i), deadline);
          const content = await withDeadline(page.getTextContent(), deadline);
          const strings = content.items.map((item) => "str" in item ? item.str : "").join(" ");
          text += strings + "\n\n";
        } catch (e) {
          if (!(e instanceof ParseTimeout)) throw e;
          truncatedAtPage = i;
          break;
        }
        if (text.length > MAX_CONTENT_CHARS) {
          truncatedAtPage = i + 1;
          break;
        }
      }
    } catch (e) {
      if (!(e instanceof ParseTimeout)) throw e;
    } finally {
      void loadingTask.destroy().catch(() => {
      });
    }
    if (truncatedAtPage > 0) {
      text += pdfPageStopMarker(truncatedAtPage);
    }
    return { fileName: name, fileType: "pdf", content: capContent(text.trim()) };
  }
  if (lower.endsWith(".xlsx") || lower.endsWith(".xls")) {
    const XLSX = await import("xlsx");
    const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
    const parts = [];
    for (const sheetName of workbook.SheetNames) {
      const csv = XLSX.utils.sheet_to_csv(workbook.Sheets[sheetName], { blankrows: false }).trim();
      if (!csv) continue;
      parts.push(`## Sheet: ${sheetName}
${csv}`);
      if (parts.join("\n\n").length > MAX_CONTENT_CHARS) break;
    }
    return {
      fileName: name,
      fileType: "xlsx",
      content: capContent(parts.join("\n\n"))
    };
  }
  if (lower.endsWith(".csv")) {
    return { fileName: name, fileType: "xlsx", content: capContent(await file.text()) };
  }
  if (isImageFile(name)) {
    return {
      fileName: name,
      fileType: "image",
      content: ""
    };
  }
  if (lower.endsWith(".msg")) {
    const { default: MsgReader } = await import("@kenjiuno/msgreader");
    const arrayBuffer = await file.arrayBuffer();
    const reader = new MsgReader(arrayBuffer);
    const data = reader.getFileData();
    const to = (data.recipients ?? []).map((r) => fmtPerson(r.name, r.email)).filter(Boolean).join(", ");
    const content = emailToText({
      subject: data.subject,
      from: fmtPerson(data.senderName, data.senderEmail),
      to,
      body: data.body
    });
    return { fileName: name, fileType: "msg", content };
  }
  if (lower.endsWith(".eml")) {
    const content = await emlToText(await file.text());
    return { fileName: name, fileType: "eml", content: capContent(content) };
  }
  if (lower.endsWith(".mbox")) {
    const raw = await file.text();
    const chunks = raw.split(/^From .*$/m).map((s) => s.trim()).filter(Boolean);
    const MAX = 50;
    const parts = [];
    for (const chunk of chunks.slice(0, MAX)) {
      try {
        const t = await emlToText(chunk);
        if (t) parts.push(t);
      } catch {
      }
    }
    let content = parts.join("\n\n\u2014\u2014\u2014\n\n");
    if (chunks.length > MAX) {
      content += mboxOverflowMarker(chunks.length - MAX);
    }
    return { fileName: name, fileType: "eml", content: capContent(content) };
  }
  try {
    return { fileName: name, fileType: "other", content: capContent(await file.text()) };
  } catch {
    return { fileName: name, fileType: "other", content: "" };
  }
}
export {
  IMAGE_EXTENSIONS,
  SUPPORTED_ACCEPT,
  SUPPORTED_EXTENSIONS,
  SUPPORTED_LABEL,
  capContent,
  getFileExtension,
  isImageFile,
  isSupportedFile,
  normalizeExtractedText,
  parseFileToText
};
