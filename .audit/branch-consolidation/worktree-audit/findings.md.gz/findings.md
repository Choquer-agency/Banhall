# Working-state and ownership audit

Read-only repository inventory, target cc6b706c3b43f971d944cb703a4174eabf3134d9. Only this audit directory was written. No git mutations, cleanup, source edits, process termination, secret/environment content reads, unrelated repositories or private chats.

## Findings

39 registered worktrees; 6 dirty, with 21 tracked-modified or non-ignored untracked paths. All six dirty worktree HEADs are already contained in the target, proving that branch containment alone misses working-state work. Exact names, HEADs, branches, status and containment are in worktrees.json; current file byte identities are in dirty-file-identities.json.

The highest-impact gap is Banhall-cownose: 13 tracked modifications and one untracked component test across Convex reviews/projects/schema/crons, project UI, workspace chrome, menus and layout. Preserve the whole working state and coordinate its owner before any disposition. The audit has not judged whether these changes should ship or whether equivalent changes already exist elsewhere.

Other dirty state comprises one untracked feedback-limit probe, three privacy review prompt files, an old untracked QA story and two modified deferred-work ledgers. Ledger files require owner review; do not treat a generic merge or clean action as authorization to rewrite native lifecycle state.

Two detached worktrees are clean: 6182a5de6947d3e8fcd72024f7a720b4af0639f5 (nested QA story 8) and 8be33ce5327562c8f5852ea16c5c85ea6171b927 (old story 3). Both are contained in target and multiple local/remote refs, so neither is a currently orphaned detached tip. Historical unreachable objects/reflog-only commits were not searched.

refs.tsv inventories existing local and remote-tracking refs; refs-not-contained.json lists every tip with commits outside target. This is ancestry, not evidence that its product changes are missing. In particular local main is stale at 14d3d17 while origin/main is cc6b706; use exact target identity. No network fetch occurred, so remote-tracking refs are the local snapshot.

## Ownership and process evidence

process-cwd.json records a live lsof CWD snapshot followed by ps PPID/elapsed/state/executable metadata. It observed 85 processes in the original Banhall directory, including Codex PID 15251, node_repl/MCP workers, shells and tmux PID 98960. Only three transient audit processes were observed in consolidation. No process CWD was observed in the other registered worktrees, including cownose and the dirty native ledgers. This is not proof of inactivity: an app may use arbitrary absolute paths, its process may retain another CWD, and workers may start after capture. No argv/environment or private task history was examined.

Avoid ownership collisions with the original Banhall workspace and its live application workers, all dirty worktrees, and nested native QA run/ledger state. Perform integration in the designated consolidation worktree. No worktree can be declared safe to remove solely from this process snapshot or branch containment.

## Factory status is not completion proof

factory-ticket-status.json records 12 ticket statuses at target: 11 done, one escalated. workspace-2-drop-dead-gate-branches explicitly reports escalation: merge conflict, names its separate factory branch and retains unmet source markers at target (workspace-2-marker-check.txt). Ticket status does not establish merge ancestry, runtime validation, source equivalence or uncommitted work disposition; the 21 dirty paths above exist independently of those labels. No factory/native lifecycle command was executed and no ticket was changed.

## Dirty inventory

### /Users/johnnynguyen/Documents/Repos/Banhall-bmad-completion/.bmad-loop/runs/20260904-145336-4d56/worktrees/dw-blocking-qa-native-followup

HEAD a62e1760a9931c9451c34baa2df8af29fa1e9538; refs/heads/bmad-loop/20260904-145336-4d56

- ` M _bmad-output/implementation-artifacts/deferred-work.md`

### /Users/johnnynguyen/Documents/Repos/Banhall-bmad-feedback-probe

HEAD 8c8080576d30c919f825e12f4b786f3f28b86b8f; refs/heads/codex/bmad-feedback-probe

- `?? convex/feedbackReadLimit.probe.test.ts`

### /Users/johnnynguyen/Documents/Repos/Banhall-bmad-integration-review

HEAD 9da55bece5948da12129720dd2330a3032c985bf; refs/heads/codex/bmad-integration-review

- ` M _bmad-output/implementation-artifacts/deferred-work.md`

### /Users/johnnynguyen/Documents/Repos/Banhall-bmad-privacy-contract

HEAD a84022d0fae24281b55f58d57f4b4193d69c9dee; refs/heads/codex/bmad-privacy-contract

- `?? _bmad-output/implementation-artifacts/dw42-review-prompts/blind-hunter.md`
- `?? _bmad-output/implementation-artifacts/dw42-review-prompts/edge-case-hunter.md`
- `?? _bmad-output/implementation-artifacts/dw42-review-prompts/verification-gap.md`

### /Users/johnnynguyen/Documents/Repos/Banhall-cownose

HEAD c7167fb59d3eb46b7a21aafbad6a292ed25ea0df; refs/heads/cownose

- ` M convex/crons.ts`
- ` M convex/pdReviews.ts`
- ` M convex/projects.ts`
- ` M convex/schema.ts`
- ` M src/lib/components/editor/ModelTestSummary.svelte`
- ` M src/lib/components/project/CurrentProjectPage.svelte`
- ` M src/lib/components/ui/UserMenu.component.test.ts`
- ` M src/lib/components/ui/UserMenu.svelte`
- ` M src/lib/components/workspace/WorkspaceHeader.component.test.ts`
- ` M src/lib/components/workspace/WorkspaceRail.component.test.ts`
- ` M src/lib/components/workspace/WorkspaceRail.svelte`
- ` M src/routes/layout.css`
- ` M src/routes/project/new/+page.svelte`
- `?? src/lib/components/project/CurrentProjectReviewFeedback.component.test.ts`

### /Users/johnnynguyen/Documents/Repos/Banhall/.bmad-loop/runs/20260904-030217-50fa/worktrees/8

HEAD 0b6325cd85dbf1c01e9a1e5cff67e6eef02f7ef7; refs/heads/bmad-loop/20260904-030217-50fa

- `?? _bmad-output/specs/spec-ai-engine-sprint-2-boundary/stories/8-blocking-qa-policy.md`

