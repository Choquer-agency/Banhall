import { beforeEach, describe, expect, it } from "vitest";
import { render } from "vitest-browser-svelte";
import CurrentProjectPage from "./CurrentProjectPage.svelte";
import { __resetPage, __setPageParams, __setPageUrl } from "$lib/test/app-state-stub.svelte";
import { __resetNavigation } from "$lib/test/app-navigation-stub";
import { __resetConvexStub, __setQueryData } from "$lib/test/convex-svelte-stub.svelte";

/**
 * Regression for the 2026-08-19 flag on review-mode projects: after
 * "Generate PD for comparison" produced a report, the review summary and
 * suggestions disappeared, because CurrentProjectPage only rendered
 * PdReviewReport in its no-report intake branch. The feedback must stay
 * visible alongside the generated PD (the 2026-08-11 second-amendment
 * behavior PreviewProjectPage already had).
 */
function seedReviewProjectWithReport() {
  __setQueryData("projects:getProject", {
    _id: "project-1",
    title: "Acuity Platform Unified Identity",
    sredTitle: "",
    clientName: "Acuity Insights Inc.",
    writer: "Wren Writer",
    interviewer: "",
    interviewees: [],
    createdAt: 1753747200000,
    fiscalYearEnd: null,
    industry: null,
    scienceCode: null,
    tagIds: [],
    mode: "review",
    status: "draft",
    workflowStage: "drafting",
    shareToken: "tok-1",
    createdBy: "u-1",
  });
  // The comparison draft generated FROM the review — the state that used to
  // hide the feedback for good.
  __setQueryData("reports:getLatestReport", {
    _id: "report-1",
    projectId: "project-1",
    content: "<h1>Project 001</h1><p>Comparison draft body.</p>",
    revision: 1,
  });
  __setQueryData("generations:getLatestGeneration", null);
  __setQueryData("pdReviews:getLatestPdReview", {
    _id: "review-1",
    projectId: "project-1",
    documentId: "doc-1",
    sourceFileName: "written-pd.docx",
    status: "completed",
    result: JSON.stringify({
      summary: "The written PD is solid but underclaims the uncertainty.",
      qualitative_score: 72,
      score_rationale: "Clear work description, weak uncertainty framing.",
      strengths: ["Concrete iteration record"],
      risks: ["Uncertainty reads as routine debugging"],
      suggested_strengthening: ["Lead section 242 with the unknown"],
    }),
    createdAt: 1755640000000,
    completedAt: 1755640300000,
  });
  __setQueryData("transcripts:getTranscript", null);
  __setQueryData("reportViews:getViewSummary", null);
  __setQueryData("tags:listTags", []);
  __setQueryData("documents:listDocuments", []);
  __setQueryData("comments:listComments", []);
  __setQueryData("snapshots:getGhostSnapshot", null);
  __setQueryData("users:getCurrentUser", {
    _id: "u-1",
    role: "writer",
    firstName: "Wren",
    lastName: "Writer",
    email: "wren@example.test",
  });
}

describe("CurrentProjectPage review feedback with a generated report", () => {
  beforeEach(() => {
    localStorage.clear();
    __resetPage();
    __resetNavigation();
    __resetConvexStub();
    document.body.innerHTML = "";
  });

  it("keeps the PD review summary and suggestions visible alongside the comparison draft", async () => {
    __setPageUrl("/project/project-1");
    __setPageParams({ id: "project-1" });
    seedReviewProjectWithReport();
    await render(CurrentProjectPage, {});

    // Report surface mounted (not the intake branch)…
    await expect
      .poll(() => document.body.textContent)
      .toContain("Comparison draft body.");
    // …and the review feedback is still on the page with it.
    expect(document.body.textContent).toContain(
      "The written PD is solid but underclaims the uncertainty."
    );
    expect(document.body.textContent).toContain("written-pd.docx");
    expect(document.body.textContent).toContain("Lead section 242 with the unknown");
  });
});
