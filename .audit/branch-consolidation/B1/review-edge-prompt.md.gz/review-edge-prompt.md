Read `/Users/johnnynguyen/Documents/Repos/Banhall-branch-consolidation/_bmad/render/bmad-build/banhall-branch-consolidation-e925746067f5/1b67cd0ee1d52bcf8eb9/review-prompts/edge-case-hunter.md` completely and follow it as your review instructions.

Review content:

diff --git a/src/lib/parseDocument.test.ts b/src/lib/parseDocument.test.ts
index b901868..913b1ab 100644
--- a/src/lib/parseDocument.test.ts
+++ b/src/lib/parseDocument.test.ts
@@ -1,4 +1,4 @@
-import { describe, expect, it } from "vitest";
+import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
 import * as XLSX from "xlsx";
 import {
   capContent,
@@ -16,6 +16,12 @@ import {
   pdfPageStopMarker,
 } from "../../shared/documentStatus";
 
+const pdfjs = vi.hoisted(() => ({ getDocument: vi.fn() }));
+vi.mock("pdfjs-dist", () => ({
+  GlobalWorkerOptions: { workerSrc: "" },
+  getDocument: pdfjs.getDocument,
+}));
+
 describe("supported file registry", () => {
   it("accept attribute covers every supported extension", () => {
     const accepted = SUPPORTED_ACCEPT.split(",").map((s) => s.replace(".", ""));
@@ -150,3 +156,147 @@ describe("normalizeExtractedText", () => {
     expect(capContent("a\r\n\r\n\r\nb   ")).toBe("a\n\nb");
   });
 });
+
+/**
+ * PERF-1: the whole-file PDF deadline. `withDeadline` races the real work
+ * against one absolute deadline shared by the document load and every page
+ * call, so the timer it allocates has to be released when the work settles —
+ * otherwise a successful N-page parse leaves 2N+1 callbacks alive for up to a
+ * minute after the upload is done. `pdfjs-dist` is the only boundary mocked;
+ * the parser itself runs for real.
+ */
+describe("PDF parse deadline", () => {
+  const pdfFile = () => new File([new Uint8Array([37, 80, 68, 70])], "report.pdf");
+  /** Resolves at `ms` on the fake clock. The timer it uses is always advanced
+   * past before a test asserts the parser's own timer count. */
+  const after = <T,>(ms: number, value: T) =>
+    new Promise<T>((resolve) => setTimeout(() => resolve(value), ms));
+  const never = () => new Promise<never>(() => {});
+
+  type PageSpec = {
+    text?: string;
+    getPage?: Promise<never>;
+    /** Called when the parser asks the page for its text, so a test can observe when. */
+    textContent?: () => Promise<{ items: { str: string }[] }>;
+  };
+
+  let destroyCalls = 0;
+
+  /** Install a fake pdfjs document. `load` is the loadingTask promise. */
+  function installPdf(load: Promise<unknown> | "immediate", pages: PageSpec[] = []) {
+    destroyCalls = 0;
+    const pdf = {
+      numPages: pages.length,
+      getPage: (i: number) => {
+        const spec = pages[i - 1];
+        return spec.getPage ?? Promise.resolve({
+          getTextContent: () =>
+            spec.textContent?.() ??
+            Promise.resolve({ items: (spec.text ?? "").split(" ").map((str) => ({ str })) }),
+        });
+      },
+    };
+    pdfjs.getDocument.mockReturnValue({
+      promise: load === "immediate" ? Promise.resolve(pdf) : load.then(() => pdf),
+      destroy: () => {
+        destroyCalls++;
+        return Promise.resolve();
+      },
+    });
+  }
+
+  beforeEach(() => {
+    vi.useFakeTimers();
+    pdfjs.getDocument.mockReset();
+  });
+  afterEach(() => {
+    vi.useRealTimers();
+  });
+
+  it("leaves no pending timers after a successful multi-page parse", async () => {
+    installPdf("immediate", [{ text: "Page one" }, { text: "Page two" }, { text: "Page three" }]);
+
+    const parsed = await parseFileToText(pdfFile());
+
+    expect(parsed).toEqual({
+      fileName: "report.pdf",
+      fileType: "pdf",
+      content: "Page one\n\nPage two\n\nPage three",
+    });
+    expect(destroyCalls).toBe(1);
+    expect(vi.getTimerCount()).toBe(0);
+  });
+
+  it("keeps one cumulative 60s budget across the load and every page", async () => {
+    const page1TextContent = vi.fn(() => after(20_000, { items: [{ str: "Page" }, { str: "one" }] }));
+    const page2TextContent = vi.fn(never);
+    installPdf(after(20_000, null), [
+      { textContent: page1TextContent },
+      { textContent: page2TextContent },
+    ]);
+
+    let settled = false;
+    const pending = parseFileToText(pdfFile()).then((r) => {
+      settled = true;
+      return r;
+    });
+
+    // t=20s: the load resolves and the parser asks page 1 for its text. Page 2
+    // has not been reached, so its work has not started consuming the budget.
+    await vi.advanceTimersByTimeAsync(20_000);
+    expect(page1TextContent).toHaveBeenCalledTimes(1);
+    expect(page2TextContent).not.toHaveBeenCalled();
+
+    // t=40s: page 1's text resolves and only then is page 2 asked for its text.
+    await vi.advanceTimersByTimeAsync(20_000);
+    expect(page2TextContent).toHaveBeenCalledTimes(1);
+
+    // A per-call 60s timeout would restart the clock on page 2 at t=40s and
+    // still be waiting here — and at t=60s.
+    await vi.advanceTimersByTimeAsync(19_999);
+    expect(settled).toBe(false);
+
+    await vi.advanceTimersByTimeAsync(1);
+    const parsed = await pending;
+    expect(parsed.content).toBe(`Page one\n${pdfPageStopMarker(2)}`);
+    expect(destroyCalls).toBe(1);
+    expect(vi.getTimerCount()).toBe(0);
+  });
+
+  it("returns empty text with no page marker when the document never loads", async () => {
+    installPdf(never());
+
+    const pending = parseFileToText(pdfFile());
+    await vi.advanceTimersByTimeAsync(60_000);
+    const parsed = await pending;
+
+    expect(parsed.content).toBe("");
+    expect(parsed.content).not.toContain("Stopped reading at page");
+    expect(destroyCalls).toBe(1);
+    expect(vi.getTimerCount()).toBe(0);
+  });
+
+  it.each([
+    ["the document load rejects", (boom: Error) => installPdf(Promise.reject(boom))],
+    [
+      "getPage rejects",
+      (boom: Error) => installPdf("immediate", [{ getPage: Promise.reject(boom) }]),
+    ],
+    [
+      "a later page's getTextContent rejects",
+      (boom: Error) =>
+        installPdf("immediate", [
+          { text: "Page one" },
+          { textContent: () => Promise.reject(boom) },
+        ]),
+    ],
+  ])("propagates the original error and cleans up when %s", async (_name, install) => {
+    const boom = new Error("pdfjs exploded");
+    install(boom);
+
+    await expect(parseFileToText(pdfFile())).rejects.toBe(boom);
+
+    expect(destroyCalls).toBe(1);
+    expect(vi.getTimerCount()).toBe(0);
+  });
+});
diff --git a/src/lib/parseDocument.ts b/src/lib/parseDocument.ts
index bb0bf16..1f7a3c5 100644
--- a/src/lib/parseDocument.ts
+++ b/src/lib/parseDocument.ts
@@ -64,12 +64,16 @@ class ParseTimeout extends Error {
 function withDeadline<T>(promise: Promise<T>, deadline: number): Promise<T> {
   const ms = deadline - Date.now();
   if (ms <= 0) return Promise.reject(new ParseTimeout());
+  // Release the timer as soon as the race settles: the deadline is shared by
+  // the document load and every page, so without this a successful N-page
+  // parse leaves 2N+1 callbacks alive for the rest of the minute.
+  let timer: ReturnType<typeof setTimeout> | undefined;
   return Promise.race([
     promise,
     new Promise<never>((_, reject) => {
-      setTimeout(() => reject(new ParseTimeout()), ms);
+      timer = setTimeout(() => reject(new ParseTimeout()), ms);
     }),
-  ]);
+  ]).finally(() => clearTimeout(timer));
 }
 
 export function capContent(content: string): string {

diff --git a/_bmad-output/implementation-artifacts/spec-branch-b1-parser-lifetime.md b/_bmad-output/implementation-artifacts/spec-branch-b1-parser-lifetime.md
new file mode 100644
index 0000000..b710445
--- /dev/null
+++ b/_bmad-output/implementation-artifacts/spec-branch-b1-parser-lifetime.md
@@ -0,0 +1,71 @@
+---
+title: 'Branch consolidation B1: parser resource lifetime and deadline proof'
+type: 'bugfix'
+created: '2026-09-05'
+status: 'in-review'
+review_loop_iteration: 0
+baseline_commit: 'cc6b706c3b43f971d944cb703a4174eabf3134d9'
+authorization_basis: "User requested all remaining branches merged properly with thorough audit; this is the first coherent implementation unit within that authorization."
+context:
+  - '{project-root}/AGENTS.md'
+---
+
+<frozen-after-approval reason="user-authorized branch consolidation; preserve existing parser contract">
+
+## Intent
+
+**Problem:** Current main retains the PDF parser implementation from before an already developed timer-lifetime fix. Its timeout race can leave a pending timer after parsing settles. The outstanding branch also contains a test proving PDF loading and page extraction consume sequential portions of one shared deadline; that useful proof is absent from main.
+
+**Approach:** Integrate the narrow parser source and test changes from the audited branch, reproducing the old resource-lifetime failure and verifying the corrected behavior on the current main baseline. This is B1 of the branch-consolidation manifest. Other independent batches remain queued and are not deferred or abandoned.
+
+## Boundaries & Constraints
+
+**Always:** Preserve the single absolute 60-second parse deadline, the existing ParseTimeout identity and normal parsing output. Release the timer when either race participant settles, including rejection. Preserve all unrelated main tests. Work only in the Banhall-branch-consolidation checkout. Keep an actual before/after evidence record with exact source identities. The user explicitly chose BMAD and authorized implementation, verification and subsequent parent-managed merging; the generic factory requirement to use its engine does not replace this workflow.
+
+**Ask First:** A change to timeout duration, supported documents, error contract or product behavior beyond resource cleanup requires an actual new intent decision. Report a conflict rather than inventing that decision.
+
+**Never:** Change the current editor, AI/domain policies, native run state or deferred ledger. Do not import the Editor.component.test.ts portion of the sequential-proof commit; it belongs to B2. Do not read secrets, mutate another worktree, run remote operations, push, merge branches or commit from the implementation worker. The parent owns reviews, gates and commits.
+
+## I/O & Edge-Case Matrix
+
+| Scenario | Input / State | Expected Output / Behavior | Error Handling |
+| --- | --- | --- | --- |
+| Fulfilled operation | A wrapped operation settles before its deadline | Return its result and leave no timeout timer | No artificial timeout later |
+| Rejected operation | The operation rejects before its deadline | Preserve the original rejection and release its timer | No swallowed error |
+| Deadline expiration | The operation stays pending past remaining budget | Reject with the existing ParseTimeout contract | Timer resource is settled |
+| Sequential PDF stages | Document load consumes part of the shared absolute budget | Page extraction receives only the remaining time | Eager or per-stage reset implementations fail the proof |
+
+</frozen-after-approval>
+
+## Code Map
+
+- `src/lib/parseDocument.ts`: current parser is byte-identical to the pre-fix source; preserve public exports and shared-deadline architecture while changing the timer wrapper's cleanup.
+- `src/lib/parseDocument.test.ts`: existing maintained parser tests; integrate the timer-count checks and sequential-stage proof into this current suite.
+- `.audit/branch-consolidation/factory-audit/f82f2b0.diff`: exact source/test patch for commit f82f2b0a9c44b9f5475d6d5c31418ab368bd3c4c, useful input to inspect, not permission to expand scope.
+- `.audit/branch-consolidation/factory-audit/d381a68.diff`: exact mixed patch for d381a689e74f0d30cd712134735eb58207835f00; only parser-test hunks apply here.
+- `.audit/branch-consolidation/factory-audit/perf-1-parser-timers-editor-index-ticket.md` and `proof-1-parser-budget-sequence-ticket.md`: original intended behavior and acceptance; corresponding evidence files preserve historical observations but do not replace a current run.
+- `.audit/branch-consolidation/factory-audit/integration-batches.json`: B1 scope and later B2 editor dependency. Keep all other batches untouched.
+- `scripts/loop-verify.sh`: parent-run numbered gate. Current main uses canonical discovery and isolated fine/coarse browser contexts; retain them.
+
+## Tasks & Acceptance
+
+**Execution:**
+- [x] `src/lib/parseDocument.test.ts`: add the applicable regression cases first and run them on unchanged main source; retain the actual baseline failures.
+- [x] `src/lib/parseDocument.ts`: apply the narrow timer-lifetime repair while preserving deadline and error semantics.
+- [x] `src/lib/parseDocument.test.ts`: integrate the sequential shared-budget proof; verify an intentionally eager or resetting control fails if practical without leaving the control in source.
+- [x] `.audit/branch-consolidation/B1/`: record actual commands, exit status, concise observations and SHA256 source identities; report implementation readiness without claiming parent review or final merge completion.
+
+**Acceptance Criteria:**
+- Given each matrix input, when the actual parser wrapper is exercised, then the corresponding result/error and timer state are asserted by an executed test.
+- Given main's parser before the fix, when the new timer regression executes, then it fails for the intended leaked-resource reason; the final implementation passes it.
+- Given PDF loading has consumed part of the absolute deadline, when page extraction begins, then the test proves only remaining budget is available.
+- Given the branch's mixed parser/editor proof commit, when B1 is complete, then no editor or unrelated tracked source file changed.
+
+## Spec Change Log
+
+## Verification
+
+**Commands:**
+- `npx vitest run src/lib/parseDocument.test.ts`: retain actual failing baseline and passing final output.
+- `git diff --check`: no introduced whitespace defects.
+- Parent follows with independent BMAD review and `VERIFY_COMPONENT=1 bash scripts/loop-verify.sh` on the reviewed source before admitting this batch. If sandbox restrictions prevent an implementation-worker test, report the exact failure so the parent can execute it directly; never claim a pass.

diff --git a/.audit/branch-consolidation/B1/evidence.md b/.audit/branch-consolidation/B1/evidence.md
new file mode 100644
index 0000000..a357ac7
--- /dev/null
+++ b/.audit/branch-consolidation/B1/evidence.md
@@ -0,0 +1,33 @@
+# B1 implementation evidence
+
+Baseline commit: `cc6b706c3b43f971d944cb703a4174eabf3134d9`. Implementation is uncommitted and ready for parent review.
+
+The full spec and its sole frontmatter context file, `AGENTS.md`, were read before edits, along with factory rules and the audited parser patches. The explicit implementation-worker scope takes precedence over generic factory isolation/shipping and BMAD parent dispatch/review steps. No native state or deferred ledger was modified.
+
+## Actual commands and outcomes
+
+All commands ran in the designated Banhall-branch-consolidation checkout using its existing dependencies. No dependency changes or installation were performed.
+
+| Command | Source identity | Exit | Observation |
+| --- | --- | --- | --- |
+| `npx vitest run src/lib/parseDocument.test.ts` | `baseline.sha256` | 1 | 4 failed, 15 passed. Pending timer counts were 7, 1, 2, 5 rather than 0. |
+| `npx vitest run src/lib/parseDocument.test.ts` | `final.sha256` | 0 | All 19 tests passed. |
+| `npx vitest run src/lib/parseDocument.test.ts --testNamePattern '^PDF parse deadline keeps one cumulative 60s budget across the load and every page$' --expect.requireAssertions` | `eager-control.sha256` | 1 | Page 2 had already been called at 20 seconds, failing the intended phase assertion. |
+| Same filtered command after restoring lazy fixture | `final.sha256` | 0 | 1 passed, 18 deliberately filtered out. |
+| `git diff --check` | final diff | 0 | No whitespace defects. |
+| `shasum -a 256 -c .audit/branch-consolidation/B1/final.sha256` | final source and tests | 0 | Both files OK after restoring the control. |
+| `git diff --name-only` | final working tree | 0 | Only `src/lib/parseDocument.ts` and `src/lib/parseDocument.test.ts`. |
+
+Raw output is in `baseline.log`, `final.log`, `eager-control.log`, `sequential-final.log`, and `diff-check.log`; corresponding `.exit` files retain exit statuses. `scope.log` retains the final tracked-file list. `baseline-test.patch`, `eager-control.patch`, and `final.patch` permit reconstruction of the tested variants from the baseline. SHA256 manifests identify exact source bytes. The baseline parser hash was checked against `git show cc6b706c3b43f971d944cb703a4174eabf3134d9:src/lib/parseDocument.ts`.
+
+## Acceptance mapping
+
+- Fulfillment: successful three-page parse asserts exact text, one destroy call, and zero timers. Baseline failed with 7 timers; final passes.
+- Rejection: document load, getPage, and later getTextContent cases assert the identical original error, one destroy call, and zero timers. Baseline failed with 1, 2, and 5 timers; final passes.
+- Expiration: never-loading document returns existing empty-text behavior with no marker and zero timers. Sequential page timeout returns exact partial text plus page-2 marker, exercising the existing ParseTimeout handling. Both execute in the passing full suite.
+- Sequential budget: lazy text callback starts at 20 seconds; page 2 begins at 40 seconds; parse remains pending at 59,999 ms and returns at 60,000 ms. The eager control fails specifically at the 20-second page-2 assertion. Control bytes were restored and hashes verified.
+- Scope: production change is the exact f82f2b0a9c44b9f5475d6d5c31418ab368bd3c4c timer patch. Parser tests integrate both audited commits, including d381a689e74f0d30cd712134735eb58207835f00 sequential proof. One redundant `as Promise<never>` cast was omitted. Existing main tests remain; no editor hunk was imported.
+
+## Remaining work and limits
+
+Parent-owned independent BMAD review, `VERIFY_COMPONENT=1 bash scripts/loop-verify.sh`, commits, and merge admission remain pending. No final acceptance or merge is claimed. These tests run the real parser with only the pdfjs boundary mocked; they do not prove a real PDF in Chromium. Audit artifacts live under the repository's ignored `.audit` directory and remain available for parent inspection.


Do not invoke any skill. If the instruction file is unreadable, report that exact failure and stop. Return only the review result.
